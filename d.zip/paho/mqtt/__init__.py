__version__ = "1.5.0.dev0"


class MQTTException(Exception):
    pass
