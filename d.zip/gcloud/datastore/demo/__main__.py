from gcloud import demo
from gcloud import datastore


demo.DemoRunner.from_module(datastore).run()
