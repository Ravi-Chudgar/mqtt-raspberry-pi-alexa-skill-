from gcloud import demo
from gcloud import storage


demo.DemoRunner.from_module(storage).run()
